package com.niit.dao;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.niit.configuration.AnnotationConfig;
import com.niit.model.Customer;
import com.niit.model.Product;
import com.niit.model.User;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= {AnnotationConfig.class,CustomerDaoImpl.class})
@Transactional
public class CustomerDaoImplTest1 {

	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AnnotationConfig.class,CustomerDaoImpl.class);
	@Test
	public void testRegisterCustomer() {
		Customer customer=new Customer();
		CustomerDao customerDao=(CustomerDao)context.getBean("customerDaoImpl");
		customerDao.registerCustomer(customer);
		assertTrue(customer.getId()>0);
	}

	@Test
	public void testIsEmailValid() {
		CustomerDao customerDao=(CustomerDao)context.getBean("customerDaoImpl");
		boolean actual=customerDao.isEmailValid("nickmhatre1797@gmail.com");//duplicate email address
		assertFalse(actual);
		boolean actual1=customerDao.isEmailValid("johny.smith@xyz.com");
		assertTrue(actual1);
	}


	@Test
	public void testIsUsernameValid() {
		CustomerDao customerDao=(CustomerDao)context.getBean("customerDaoImpl");
		boolean actual=customerDao.isUsernameValid("nick");//duplicate email address
		assertFalse(actual);
		boolean actual1=customerDao.isUsernameValid("viraj");
		assertTrue(actual1);

	}

	@Test
	public void testGetUser() {
		CustomerDao customerDao=(CustomerDao)context.getBean("customerDaoImpl");
		User customer=customerDao.getUser("nick");
		assertNotNull(customer);
		User customer1=customerDao.getUser("viju");
		assertNull(customer1);

	}

}
