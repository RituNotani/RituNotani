package com.niit.dao;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.niit.configuration.AnnotationConfig;
import com.niit.model.Cart;

import com.niit.model.CustomerOrder;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= {AnnotationConfig.class,ProductDaoImpl.class})
@Transactional

public class CartItemDaoImplTest {
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AnnotationConfig.class,ProductDaoImpl.class);
	CartItemDao cartItemDao=(CartItemDao)context.getBean("cartItemDaoImpl");
	@Test
	public void testSaveOrUpdateCartItem() {
		
	}

	@Test
	public void testRemoveCartItem() {
		
	}

	@Test
	public void testGetCart() {
		Cart cart=cartItemDao.getCart(1);
		assertNotNull(cart);
		Cart cart1=cartItemDao.getCart(66);
		assertNull(cart1);
	}

	@Test
	public void testCreateOrder() {
		Cart cart=cartItemDao.getCart(1);
		CustomerOrder customerOrder=cartItemDao.createOrder(cart);
		assertTrue(customerOrder.getOrderId()>0);
		assertTrue(customerOrder.getCart().getGrandTotal()==1700.0);
	}

}
